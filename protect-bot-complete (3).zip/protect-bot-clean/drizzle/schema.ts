import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Bot configuration table - stores bot token and settings per server
 */
export const botConfigs = mysqlTable("bot_configs", {
  id: int("id").autoincrement().primaryKey(),
  serverId: varchar("serverId", { length: 64 }).notNull().unique(),
  botToken: text("botToken").notNull(), // Encrypted token
  ownerId: int("ownerId").notNull().references(() => users.id),
  botName: varchar("botName", { length: 255 }).default("GuardBot"),
  botPrefix: varchar("botPrefix", { length: 10 }).default("!"),
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BotConfig = typeof botConfigs.$inferSelect;
export type InsertBotConfig = typeof botConfigs.$inferInsert;

/**
 * Slash commands table - stores available commands and their settings
 */
export const slashCommands = mysqlTable("slash_commands", {
  id: int("id").autoincrement().primaryKey(),
  commandName: varchar("commandName", { length: 64 }).notNull().unique(),
  description: text("description").notNull(),
  usage: varchar("usage", { length: 255 }),
  category: varchar("category", { length: 64 }).default("moderation"),
  isEnabled: int("isEnabled").default(1).notNull(),
  requiredPermission: varchar("requiredPermission", { length: 255 }).default("MODERATE_MEMBERS"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SlashCommand = typeof slashCommands.$inferSelect;
export type InsertSlashCommand = typeof slashCommands.$inferInsert;

/**
 * Bot statistics table - tracks bot usage and metrics
 */
export const botStatistics = mysqlTable("bot_statistics", {
  id: int("id").autoincrement().primaryKey(),
  serverId: varchar("serverId", { length: 64 }).notNull(),
  serversCount: int("serversCount").default(0),
  totalUsers: int("totalUsers").default(0),
  commandsExecuted: int("commandsExecuted").default(0),
  bansIssued: int("bansIssued").default(0),
  kicksIssued: int("kicksIssued").default(0),
  mutesIssued: int("mutesIssued").default(0),
  warnsIssued: int("warnsIssued").default(0),
  messagesCleared: int("messagesCleared").default(0),
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BotStatistic = typeof botStatistics.$inferSelect;
export type InsertBotStatistic = typeof botStatistics.$inferInsert;

/**
 * Authorization table - manages server and user permissions
 */
export const authorizations = mysqlTable("authorizations", {
  id: int("id").autoincrement().primaryKey(),
  serverId: varchar("serverId", { length: 64 }).notNull(),
  userId: varchar("userId", { length: 64 }),
  roleId: varchar("roleId", { length: 64 }),
  permissionLevel: mysqlEnum("permissionLevel", ["owner", "admin", "moderator", "user", "banned"]).default("user"),
  canBan: int("canBan").default(0),
  canKick: int("canKick").default(0),
  canMute: int("canMute").default(0),
  canWarn: int("canWarn").default(0),
  canClear: int("canClear").default(0),
  canSetup: int("canSetup").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Authorization = typeof authorizations.$inferSelect;
export type InsertAuthorization = typeof authorizations.$inferInsert;