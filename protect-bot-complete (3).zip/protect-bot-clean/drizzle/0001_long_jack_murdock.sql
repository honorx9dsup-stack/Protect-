CREATE TABLE `authorizations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`serverId` varchar(64) NOT NULL,
	`userId` varchar(64),
	`roleId` varchar(64),
	`permissionLevel` enum('owner','admin','moderator','user','banned') DEFAULT 'user',
	`canBan` int DEFAULT 0,
	`canKick` int DEFAULT 0,
	`canMute` int DEFAULT 0,
	`canWarn` int DEFAULT 0,
	`canClear` int DEFAULT 0,
	`canSetup` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `authorizations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bot_configs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`serverId` varchar(64) NOT NULL,
	`botToken` text NOT NULL,
	`ownerId` int NOT NULL,
	`botName` varchar(255) DEFAULT 'GuardBot',
	`botPrefix` varchar(10) DEFAULT '!',
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bot_configs_id` PRIMARY KEY(`id`),
	CONSTRAINT `bot_configs_serverId_unique` UNIQUE(`serverId`)
);
--> statement-breakpoint
CREATE TABLE `bot_statistics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`serverId` varchar(64) NOT NULL,
	`serversCount` int DEFAULT 0,
	`totalUsers` int DEFAULT 0,
	`commandsExecuted` int DEFAULT 0,
	`bansIssued` int DEFAULT 0,
	`kicksIssued` int DEFAULT 0,
	`mutesIssued` int DEFAULT 0,
	`warnsIssued` int DEFAULT 0,
	`messagesCleared` int DEFAULT 0,
	`lastUpdated` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bot_statistics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `slash_commands` (
	`id` int AUTO_INCREMENT NOT NULL,
	`commandName` varchar(64) NOT NULL,
	`description` text NOT NULL,
	`usage` varchar(255),
	`category` varchar(64) DEFAULT 'moderation',
	`isEnabled` int NOT NULL DEFAULT 1,
	`requiredPermission` varchar(255) DEFAULT 'MODERATE_MEMBERS',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `slash_commands_id` PRIMARY KEY(`id`),
	CONSTRAINT `slash_commands_commandName_unique` UNIQUE(`commandName`)
);
--> statement-breakpoint
ALTER TABLE `bot_configs` ADD CONSTRAINT `bot_configs_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;