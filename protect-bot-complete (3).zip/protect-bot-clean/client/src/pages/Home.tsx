import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { getLoginUrl } from "@/const";
import { Shield, Eye, Lock, BarChart3, Zap, Users, MessageSquare, Settings } from "lucide-react";
import { useLocation } from "wouter";

const SLASH_COMMANDS = [
  { name: "/ban", description: "Ban a user from the server" },
  { name: "/kick", description: "Kick a user from the server" },
  { name: "/mute", description: "Mute a user temporarily" },
  { name: "/warn", description: "Issue a warning to a user" },
  { name: "/clear", description: "Clear messages from a channel" },
  { name: "/setup", description: "Configure bot settings" },
  { name: "/help", description: "View all available commands" },
];

const FEATURES = [
  {
    icon: Shield,
    title: "Advanced Protection",
    description: "Real-time threat detection and intelligent monitoring for your Discord server",
  },
  {
    icon: Eye,
    title: "Real-time Monitoring",
    description: "Live activity tracking and comprehensive logging of all server events",
  },
  {
    icon: Lock,
    title: "Access Control",
    description: "Granular permission management with role-based authorization",
  },
  {
    icon: BarChart3,
    title: "Security Analytics",
    description: "Detailed insights and statistics about your server's security",
  },
];

const FAQS = [
  {
    question: "How do I add PROTECT BOT to my server?",
    answer: "Click the 'Add PROTECT BOT' button, authorize the bot, and select your Discord server. The bot will be ready to use immediately.",
  },
  {
    question: "Can I customize the bot's behavior?",
    answer: "Yes! Use the /setup command or access the dashboard to configure permissions, moderation rules, and custom settings.",
  },
  {
    question: "Is my data secure?",
    answer: "Absolutely. We use enterprise-grade encryption and follow Discord's security best practices to protect your data.",
  },
  {
    question: "Do you offer support?",
    answer: "Yes! Join our support server for help, feature requests, and community discussions.",
  },
  {
    question: "Can I use PROTECT BOT in multiple servers?",
    answer: "Yes, one bot instance can manage multiple servers with independent configurations for each.",
  },
];

export default function Home() {
  const { loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin mb-4">
            <Shield className="w-12 h-12 text-primary mx-auto" />
          </div>
          <p className="text-foreground">Loading PROTECT BOT...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663763961817/k6WifLSKBMTEZccHuM4Ror/protect-bot-logo-VSXXfajVjNKhnyThr9DJvf.webp" alt="PROTECT BOT" className="w-8 h-8" />
            <span className="font-bold text-lg text-foreground">PROTECT BOT</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="#features" className="text-sm text-foreground/70 hover:text-foreground transition">Features</a>
            <a href="#commands" className="text-sm text-foreground/70 hover:text-foreground transition">Commands</a>
            <a href="#faq" className="text-sm text-foreground/70 hover:text-foreground transition">FAQ</a>
            <Button asChild>
              <a href={getLoginUrl()}>Login</a>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />
        <div className="container max-w-6xl mx-auto px-4 relative">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
                Advanced Protection for Discord
              </h1>
              <p className="text-xl text-foreground/70 mb-8">
                PROTECT BOT provides enterprise-grade security, real-time monitoring, and intelligent threat detection for your Discord server.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" asChild>
                  <a href={getLoginUrl()}>Get Started</a>
                </Button>
                <Button size="lg" variant="outline">
                  Learn More
                </Button>
              </div>
              <div className="flex items-center gap-8 mt-12 text-sm text-foreground/60">
                <div>
                  <div className="font-bold text-foreground">10K+</div>
                  <div>Servers Protected</div>
                </div>
                <Separator orientation="vertical" className="h-8" />
                <div>
                  <div className="font-bold text-foreground">500K+</div>
                  <div>Users Secured</div>
                </div>
                <Separator orientation="vertical" className="h-8" />
                <div>
                  <div className="font-bold text-foreground">99.9%</div>
                  <div>Uptime</div>
                </div>
              </div>
            </div>
            <div className="relative h-96 lg:h-full">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663763961817/k6WifLSKBMTEZccHuM4Ror/hero-image-fLnfTZVSiuqcab7dXEYrvA.webp"
                alt="PROTECT BOT Dashboard"
                className="w-full h-full object-cover rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-card/50">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Powerful Features</h2>
            <p className="text-lg text-foreground/70">Everything you need to keep your Discord server safe and secure</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {FEATURES.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <Card key={idx} className="border-border hover:border-primary/50 transition">
                  <CardHeader>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-foreground/70">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Commands Section */}
      <section id="commands" className="py-20">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Slash Commands</h2>
            <p className="text-lg text-foreground/70">Powerful commands to manage and protect your server</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {SLASH_COMMANDS.map((cmd, idx) => (
              <Card key={idx} className="border-border">
                <CardHeader>
                  <CardTitle className="text-base font-mono text-primary">{cmd.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-foreground/70">{cmd.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Getting Started Section */}
      <section className="py-20 bg-card/50">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Getting Started</h2>
            <p className="text-lg text-foreground/70">Three simple steps to protect your server</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: "1",
                title: "Add PROTECT BOT",
                description: "Click the button below and authorize PROTECT BOT to access your server",
              },
              {
                step: "2",
                title: "Configure Settings",
                description: "Use the dashboard to customize permissions and moderation rules",
              },
              {
                step: "3",
                title: "Start Protecting",
                description: "Your server is now protected with real-time threat detection",
              },
            ].map((item, idx) => (
              <div key={idx} className="text-center">
                <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-foreground/70">{item.description}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Button size="lg" asChild>
              <a href={getLoginUrl()}>Add PROTECT BOT Now</a>
            </Button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Frequently Asked Questions</h2>
          </div>
          <div className="space-y-4">
            {FAQS.map((faq, idx) => (
              <Card key={idx} className="border-border">
                <CardHeader>
                  <CardTitle className="text-lg">{faq.question}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground/70">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary/10 to-secondary/10 border-t border-border">
        <div className="container max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-foreground mb-6">Ready to Protect Your Server?</h2>
          <p className="text-lg text-foreground/70 mb-8">
            Join thousands of Discord communities already using PROTECT BOT
          </p>
          <Button size="lg" asChild>
            <a href={getLoginUrl()}>Get Started Today</a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663763961817/k6WifLSKBMTEZccHuM4Ror/protect-bot-logo-VSXXfajVjNKhnyThr9DJvf.webp" alt="PROTECT BOT" className="w-6 h-6" />
                <span className="font-bold text-foreground">PROTECT BOT</span>
              </div>
              <p className="text-sm text-foreground/60">Advanced protection for Discord servers</p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-foreground/60">
                <li><a href="#features" className="hover:text-foreground transition">Features</a></li>
                <li><a href="#commands" className="hover:text-foreground transition">Commands</a></li>
                <li><a href="#faq" className="hover:text-foreground transition">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-foreground/60">
                <li><a href="#" className="hover:text-foreground transition">About</a></li>
                <li><a href="#" className="hover:text-foreground transition">Blog</a></li>
                <li><a href="#" className="hover:text-foreground transition">Support</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-foreground/60">
                <li><a href="#" className="hover:text-foreground transition">Privacy</a></li>
                <li><a href="#" className="hover:text-foreground transition">Terms</a></li>
              </ul>
            </div>
          </div>
          <Separator />
          <div className="mt-8 text-center text-sm text-foreground/60">
            <p>&copy; 2026 PROTECT BOT. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
