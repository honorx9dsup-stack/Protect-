import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Eye, EyeOff, Copy, Check } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Dashboard() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [showToken, setShowToken] = useState(false);
  const [tokenCopied, setTokenCopied] = useState(false);
  const [botToken, setBotToken] = useState("");

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin mb-4">
            <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full mx-auto" />
          </div>
          <p className="text-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    navigate("/");
    return null;
  }

  const handleCopyToken = () => {
    if (botToken) {
      navigator.clipboard.writeText(botToken);
      setTokenCopied(true);
      toast.success("Token copied to clipboard!");
      setTimeout(() => setTokenCopied(false), 2000);
    }
  };

  const handleSaveToken = () => {
    if (!botToken) {
      toast.error("Please enter a bot token");
      return;
    }
    toast.success("Bot token saved securely!");
    setBotToken("");
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Welcome Section */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Welcome to PROTECT BOT</h1>
          <p className="text-foreground/70 mt-2">Manage your bot settings and server protection</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { label: "Servers Protected", value: "10,234", change: "+12%" },
            { label: "Total Users", value: "523,891", change: "+8%" },
            { label: "Commands Executed", value: "1.2M", change: "+24%" },
            { label: "Threats Blocked", value: "3,421", change: "+15%" },
          ].map((stat, idx) => (
            <Card key={idx} className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-foreground/70">{stat.label}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <p className="text-xs text-primary mt-1">{stat.change} from last month</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Tabs Section */}
        <Tabs defaultValue="token" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="token">Bot Token</TabsTrigger>
            <TabsTrigger value="commands">Commands</TabsTrigger>
            <TabsTrigger value="authorization">Authorization</TabsTrigger>
          </TabsList>

          {/* Bot Token Tab */}
          <TabsContent value="token" className="space-y-6">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Bot Token Management</CardTitle>
                <CardDescription>
                  Enter your Discord bot token to enable PROTECT BOT functionality
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="token">Bot Token</Label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Input
                        id="token"
                        type={showToken ? "text" : "password"}
                        placeholder="Enter your bot token"
                        value={botToken}
                        onChange={(e) => setBotToken(e.target.value)}
                        className="pr-10"
                      />
                      <button
                        onClick={() => setShowToken(!showToken)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-foreground/50 hover:text-foreground transition"
                      >
                        {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={handleCopyToken}
                      disabled={!botToken}
                    >
                      {tokenCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                  <p className="text-sm text-foreground/70">
                    <strong>Security Note:</strong> Your bot token is encrypted and stored securely. Never share your token with anyone.
                  </p>
                </div>

                <Button onClick={handleSaveToken} className="w-full">
                  Save Token
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Commands Tab */}
          <TabsContent value="commands" className="space-y-6">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Available Commands</CardTitle>
                <CardDescription>
                  Enable or disable slash commands for your server
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "/ban", description: "Ban a user from the server", enabled: true },
                    { name: "/kick", description: "Kick a user from the server", enabled: true },
                    { name: "/mute", description: "Mute a user temporarily", enabled: true },
                    { name: "/warn", description: "Issue a warning to a user", enabled: true },
                    { name: "/clear", description: "Clear messages from a channel", enabled: true },
                    { name: "/setup", description: "Configure bot settings", enabled: true },
                    { name: "/help", description: "View all available commands", enabled: true },
                  ].map((cmd, idx) => (
                    <div key={idx} className="flex items-center justify-between p-4 bg-card/50 rounded-lg border border-border">
                      <div>
                        <p className="font-mono font-semibold text-primary">{cmd.name}</p>
                        <p className="text-sm text-foreground/70">{cmd.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          defaultChecked={cmd.enabled}
                          className="w-4 h-4 rounded cursor-pointer"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Authorization Tab */}
          <TabsContent value="authorization" className="space-y-6">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Authorization Settings</CardTitle>
                <CardDescription>
                  Manage server and user permissions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="server-id">Server ID</Label>
                    <Input
                      id="server-id"
                      placeholder="Enter your Discord server ID"
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label htmlFor="permission-level">Permission Level</Label>
                    <select className="w-full mt-2 px-3 py-2 rounded-md border border-border bg-background text-foreground">
                      <option value="owner">Owner</option>
                      <option value="admin">Admin</option>
                      <option value="moderator">Moderator</option>
                      <option value="user">User</option>
                      <option value="banned">Banned</option>
                    </select>
                  </div>

                  <div className="space-y-3">
                    <Label>Permissions</Label>
                    <div className="space-y-2">
                      {[
                        { id: "ban", label: "Can Ban Users" },
                        { id: "kick", label: "Can Kick Users" },
                        { id: "mute", label: "Can Mute Users" },
                        { id: "warn", label: "Can Warn Users" },
                        { id: "clear", label: "Can Clear Messages" },
                        { id: "setup", label: "Can Setup Bot" },
                      ].map((perm) => (
                        <div key={perm.id} className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            id={perm.id}
                            className="w-4 h-4 rounded cursor-pointer"
                          />
                          <label htmlFor={perm.id} className="text-sm text-foreground cursor-pointer">
                            {perm.label}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <Button className="w-full">
                  Save Authorization Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
