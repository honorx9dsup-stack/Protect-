# 🚀 تعليمات الرفع السريعة على Vercel

## المشكلة والحل

**المشكلة:** 404 NOT_FOUND على Vercel
**السبب:** المشروع Full-Stack (React + Express) وVercel بتحتاج إعدادات خاصة
**الحل:** استخدام Vercel Functions + Static Files

---

## 3 خطوات فقط للرفع

### 1️⃣ إعداد Git

```bash
git init
git add .
git commit -m "Ready for Vercel"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### 2️⃣ ربط بـ Vercel

اذهب إلى: https://vercel.com/new
- اختر GitHub
- اختر Repository
- اضغط Import

### 3️⃣ إضافة متغيرات البيئة (مهم جداً!)

في لوحة Vercel اذهب إلى: **Settings → Environment Variables**

أضف هذه المتغيرات:

```
VITE_APP_ID = your_app_id
VITE_OAUTH_PORTAL_URL = https://oauth.manus.im
JWT_SECRET = your_secret_key_here
DATABASE_URL = mysql://user:password@host:3306/db
OAUTH_SERVER_URL = https://oauth.manus.im
OWNER_OPEN_ID = your_owner_id
BUILT_IN_FORGE_API_URL = https://api.manus.im
BUILT_IN_FORGE_API_KEY = your_api_key
NODE_ENV = production
```

---

## بعد الإضافة

1. اذهب إلى **Deployments**
2. اضغط **Redeploy** (عشان تستخدم المتغيرات الجديدة)
3. انتظر حتى ينتهي ✅

---

## ملفات مهمة

| الملف | الوصف |
|------|-------|
| `vercel.json` | إعدادات Vercel (Routing) |
| `api/index.ts` | Express server (Vercel Function) |
| `dist/public/` | الملفات الثابتة (HTML/CSS/JS) |

---

## استكشاف الأخطاء

### 404 لسه موجودة؟
- تأكد من وجود `vercel.json` و `api/index.ts`
- اضغط **Redeploy** مرة ثانية
- شوف الـ logs في Vercel

### API Errors؟
- تحقق من متغيرات البيئة
- تأكد من أن قاعدة البيانات متاحة

### Build Errors؟
- جرب `pnpm run build` محلياً
- شوف رسائل الخطأ في Vercel logs

---

## الخطوة التالية

بعد النشر بنجاح:
1. افتح الموقع وتأكد من عمل الصفحة الرئيسية
2. جرب تسجيل الدخول (OAuth)
3. افتح DevTools وتأكد من عدم وجود أخطاء

---

**تم التحديث:** 24 يونيو 2026
**الحالة:** ✅ جاهز للإنتاج
