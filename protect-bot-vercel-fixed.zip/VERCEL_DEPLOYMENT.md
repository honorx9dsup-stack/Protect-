# Vercel Deployment Guide

هذا الملف يحتوي على تعليمات كاملة لرفع المشروع على Vercel بنجاح.

## المتطلبات الأساسية

1. **حساب Vercel** - سجل في [vercel.com](https://vercel.com)
2. **Git Repository** - المشروع يجب أن يكون في GitHub أو GitLab أو Bitbucket
3. **متغيرات البيئة** - جهز جميع المتغيرات المطلوبة

## خطوات الرفع

### 1. إعداد Git Repository

```bash
# إذا لم تكن قد أنشأت repository بعد
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### 2. ربط المشروع بـ Vercel

**الطريقة الأولى: عبر واجهة Vercel**
- اذهب إلى [vercel.com/new](https://vercel.com/new)
- اختر Git provider (GitHub/GitLab/Bitbucket)
- اختر المشروع من قائمة repositories
- اضغط "Import"

**الطريقة الثانية: عبر Vercel CLI**
```bash
npm i -g vercel
vercel
```

### 3. تكوين متغيرات البيئة

في لوحة تحكم Vercel:

1. اذهب إلى **Settings** > **Environment Variables**
2. أضف المتغيرات التالية:

```
VITE_APP_ID=your_app_id_here
VITE_OAUTH_PORTAL_URL=https://oauth.manus.im
JWT_SECRET=your_jwt_secret_here
DATABASE_URL=mysql://user:password@host:3306/database_name
OAUTH_SERVER_URL=https://oauth.manus.im
OWNER_OPEN_ID=your_owner_open_id_here
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your_forge_api_key_here
NODE_ENV=production
```

### 4. تكوين قاعدة البيانات

تأكد من أن قاعدة البيانات MySQL متاحة وقابلة للوصول من Vercel:

```bash
# تشغيل migrations
pnpm run db:push
```

### 5. نشر المشروع

بعد إضافة متغيرات البيئة:

1. اذهب إلى **Deployments** في لوحة تحكم Vercel
2. اضغط **Deploy** أو انتظر التوزيع التلقائي عند push إلى main

## هيكل الملفات المهم

```
project/
├── api/
│   └── index.ts              # Vercel Function (Express server)
├── client/
│   ├── src/
│   │   ├── App.tsx
│   │   └── main.tsx
│   └── index.html
├── server/
│   ├── _core/
│   │   ├── index.ts
│   │   ├── oauth.ts
│   │   └── vite.ts
│   └── routers.ts
├── dist/                      # Build output
│   ├── public/               # Static files
│   └── index.js              # Server bundle (no longer needed for Vercel)
├── vercel.json               # Vercel configuration
├── package.json
└── vite.config.ts
```

## كيفية عمل الرفع

### Build Process
```
1. pnpm install
2. pnpm run build
   - Vite builds React frontend → dist/public/
   - Static files ready for serving
```

### Runtime on Vercel
```
1. API requests → /api/index.ts (Vercel Function)
   - Express server handles tRPC API
   - OAuth callbacks
   - Storage proxy

2. Static requests → dist/public/
   - HTML/CSS/JS files
   - SPA fallback to index.html
```

## استكشاف الأخطاء

### 404 NOT_FOUND
- تأكد من أن `vercel.json` موجود
- تحقق من أن `api/index.ts` موجود
- تأكد من أن `outputDirectory` صحيح

### API Errors
- تحقق من متغيرات البيئة في Vercel dashboard
- تأكد من أن قاعدة البيانات متاحة
- تحقق من logs في Vercel dashboard

### Build Errors
- تأكد من أن `pnpm install` يعمل بنجاح محلياً
- تحقق من رسائل الخطأ في Vercel logs
- جرب `pnpm run build` محلياً

## متغيرات البيئة المطلوبة

| المتغير | الوصف | مثال |
|---------|-------|------|
| `VITE_APP_ID` | معرف التطبيق من Manus | `abc123` |
| `JWT_SECRET` | سر التوقيع | `your_secret_key` |
| `DATABASE_URL` | رابط قاعدة البيانات | `mysql://user:pass@host/db` |
| `OAUTH_SERVER_URL` | رابط خادم OAuth | `https://oauth.manus.im` |
| `OWNER_OPEN_ID` | معرف المالك | `owner_id_123` |
| `BUILT_IN_FORGE_API_URL` | رابط Forge API | `https://api.manus.im` |
| `BUILT_IN_FORGE_API_KEY` | مفتاح Forge API | `api_key_123` |

## ملاحظات مهمة

1. **الـ Bot Token**: لا تضع Discord bot token في متغيرات البيئة العامة
2. **الأمان**: استخدم Vercel's encryption للمتغيرات الحساسة
3. **قاعدة البيانات**: تأكد من أن قاعدة البيانات آمنة وقابلة للوصول فقط من Vercel IPs
4. **الـ Logs**: استخدم `vercel logs` لمراقبة أخطاء الإنتاج

## أوامر مفيدة

```bash
# عرض logs الإنتاج
vercel logs

# إعادة نشر آخر commit
vercel --prod

# عرض معلومات المشروع
vercel projects list

# حذف deployment
vercel remove
```

## الدعم والمساعدة

- [Vercel Documentation](https://vercel.com/docs)
- [Vercel Discord Community](https://discord.gg/vercel)
- [Manus Documentation](https://docs.manus.im)
