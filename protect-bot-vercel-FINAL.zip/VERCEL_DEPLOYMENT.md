# دليل الرفع على Vercel - النسخة المحدثة

هذا الملف يحتوي على تعليمات كاملة وصحيحة لرفع المشروع على Vercel بنجاح.

## ملخص المشكلة والحل

**المشكلة الأصلية:**
- المشروع عبارة عن Full-Stack App (React + Express + tRPC)
- Vercel كانت تعامله كـ Static Site فقط
- النتيجة: 404 NOT_FOUND على جميع المسارات

**الحل:**
- أضفنا **Vercel Functions** (`api/index.ts`) لتشغيل Express server
- أضفنا **vercel.json** لتوجيه الطلبات بشكل صحيح
- الآن Vercel تعرف تفصل بين:
  - `/api/*` → يروح للـ Express server
  - `/` و باقي المسارات → يروح للـ SPA (index.html)

## المتطلبات الأساسية

1. **حساب Vercel** - سجل في [vercel.com](https://vercel.com)
2. **Git Repository** - المشروع في GitHub أو GitLab أو Bitbucket
3. **متغيرات البيئة** - جهز جميع المتغيرات المطلوبة

## خطوات الرفع خطوة بخطوة

### الخطوة 1: إعداد Git Repository

```bash
# إذا لم تكن قد أنشأت repository بعد
git init
git add .
git commit -m "Initial commit - Vercel ready"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### الخطوة 2: ربط المشروع بـ Vercel

**الطريقة الأولى: عبر واجهة Vercel (الأسهل)**
1. اذهب إلى [vercel.com/new](https://vercel.com/new)
2. اختر Git provider (GitHub/GitLab/Bitbucket)
3. اختر المشروع من قائمة repositories
4. اضغط "Import"

**الطريقة الثانية: عبر Vercel CLI**
```bash
npm i -g vercel
vercel
```

### الخطوة 3: تكوين متغيرات البيئة (مهم جداً!)

**في لوحة تحكم Vercel:**
1. اذهب إلى **Settings** → **Environment Variables**
2. أضف كل متغير من المتغيرات التالية:

```
VITE_APP_ID=your_app_id_here
VITE_OAUTH_PORTAL_URL=https://oauth.manus.im
JWT_SECRET=your_jwt_secret_here
DATABASE_URL=mysql://user:password@host:3306/database_name
OAUTH_SERVER_URL=https://oauth.manus.im
OWNER_OPEN_ID=your_owner_open_id_here
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your_forge_api_key_here
NODE_ENV=production
```

**تنبيه:** لا تنسى الضغط على "Save" بعد كل متغير!

### الخطوة 4: تشغيل Build و Deploy

بعد إضافة متغيرات البيئة:

1. اذهب إلى **Deployments** في لوحة تحكم Vercel
2. اضغط **Redeploy** (عشان تستخدم المتغيرات الجديدة)
3. انتظر حتى ينتهي البناء والنشر

## هيكل الملفات المهم

```
project/
├── api/
│   └── index.ts              ⭐ Vercel Function (Express server)
├── client/
│   ├── src/
│   │   ├── App.tsx
│   │   └── main.tsx
│   └── index.html
├── server/
│   ├── _core/
│   │   ├── oauth.ts          ← /api/oauth/callback
│   │   ├── storageProxy.ts   ← /manus-storage/*
│   │   └── vite.ts
│   └── routers.ts            ← /api/trpc
├── dist/                      # Build output
│   └── public/               # Static files (HTML/CSS/JS)
├── vercel.json               ⭐ Routing configuration
├── package.json
└── vite.config.ts
```

## كيفية عمل الرفع

### Build Process
```
1. pnpm install
2. pnpm run build
   ↓
   Vite builds React frontend → dist/public/
   ↓
   Static files ready for serving
```

### Runtime on Vercel
```
Request comes in
    ↓
Is it /api/trpc/* ?  → YES → api/index.ts (Express) → tRPC handler
    ↓ NO
Is it /api/oauth/* ? → YES → api/index.ts (Express) → OAuth handler
    ↓ NO
Is it /manus-storage/* ? → YES → api/index.ts (Express) → Storage proxy
    ↓ NO
Serve from dist/public/
    ↓
File found? → YES → Serve it
    ↓ NO
Serve index.html (SPA fallback)
```

## استكشاف الأخطاء والمشاكل

### المشكلة: 404 NOT_FOUND

**الحل:**
1. تأكد من وجود ملف `vercel.json` في جذر المشروع
2. تأكد من وجود ملف `api/index.ts`
3. تأكد من أن `outputDirectory` في `vercel.json` هو `dist/public`
4. جرب Redeploy من لوحة Vercel

### المشكلة: API Errors (500, 502, etc.)

**الحل:**
1. تحقق من متغيرات البيئة في Vercel dashboard
2. تأكد من أن قاعدة البيانات متاحة وقابلة للوصول
3. شوف الـ logs في Vercel: اذهب إلى **Deployments** → اختر deployment → **Logs**

### المشكلة: Build Errors

**الحل:**
1. جرب `pnpm run build` محلياً أولاً
2. تأكد من أن `pnpm install` يعمل بنجاح
3. شوف رسائل الخطأ في Vercel build logs
4. تأكد من أن جميع الـ dependencies موجودة في `package.json`

### المشكلة: OAuth Callback Not Working

**الحل:**
1. تأكد من أن `OAUTH_SERVER_URL` صحيح
2. تأكد من أن `VITE_APP_ID` صحيح
3. تأكد من أن رابط callback في Manus OAuth مسجل بشكل صحيح
4. الرابط يجب يكون: `https://your-domain.vercel.app/api/oauth/callback`

## متغيرات البيئة المطلوبة - شرح مفصل

| المتغير | الوصف | مثال |
|---------|-------|------|
| `VITE_APP_ID` | معرف التطبيق من Manus | `abc123def456` |
| `JWT_SECRET` | سر التوقيع (أي string عشوائي طويل) | `your_super_secret_key_123` |
| `DATABASE_URL` | رابط قاعدة البيانات MySQL | `mysql://user:pass@db.example.com:3306/mydb` |
| `OAUTH_SERVER_URL` | رابط خادم OAuth | `https://oauth.manus.im` |
| `OWNER_OPEN_ID` | معرف المالك من Manus | `owner_123_abc` |
| `BUILT_IN_FORGE_API_URL` | رابط Forge API | `https://api.manus.im` |
| `BUILT_IN_FORGE_API_KEY` | مفتاح Forge API | `forge_key_123` |
| `VITE_OAUTH_PORTAL_URL` | رابط بوابة OAuth | `https://oauth.manus.im` |

## ملاحظات أمان مهمة

1. **الـ Bot Token**: لا تضع Discord bot token في متغيرات البيئة العامة
2. **الـ Secrets**: استخدم Vercel's encryption للمتغيرات الحساسة
3. **قاعدة البيانات**: تأكد من أن قاعدة البيانات آمنة وقابلة للوصول فقط من Vercel IPs
4. **الـ Logs**: استخدم `vercel logs` لمراقبة أخطاء الإنتاج

## أوامر مفيدة

```bash
# عرض logs الإنتاج
vercel logs

# إعادة نشر آخر commit
vercel --prod

# عرض معلومات المشروع
vercel projects list

# حذف deployment
vercel remove

# عرض متغيرات البيئة
vercel env list
```

## الخطوات التالية بعد النشر

1. **اختبر الموقع**: افتح الرابط وتأكد من أن كل شي يشتغل
2. **اختبر الـ OAuth**: جرب تسجيل الدخول
3. **اختبر الـ API**: افتح DevTools وشوف Network requests
4. **أضف Domain مخصص**: في Vercel settings اضغط "Add Domain"

## الدعم والمساعدة

- [Vercel Documentation](https://vercel.com/docs)
- [Vercel Discord Community](https://discord.gg/vercel)
- [Manus Documentation](https://docs.manus.im)
- [Express.js Guide](https://expressjs.com/)

---

**آخر تحديث:** 24 يونيو 2026
**الحالة:** ✅ جاهز للإنتاج
