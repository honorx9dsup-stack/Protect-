# 🔧 استكشاف الأخطاء والحلول

## المشكلة: 404 NOT_FOUND على Vercel

### السبب الحقيقي

المشروع عبارة عن **Full-Stack Application**:
- **Frontend**: React SPA (Single Page Application)
- **Backend**: Express.js + tRPC

Vercel بشكل افتراضي بتعامل المشاريع كـ **Static Sites** فقط. لما تحاول تفتح أي صفحة (مثل `/dashboard`)، Vercel بتدور على ملف اسمه `dashboard.html` في الملفات الثابتة، وما بتلاقيه، فبتعطيك 404.

### الحل الصحيح

استخدام **Vercel Functions** (Serverless) لتشغيل Express server:

1. **vercel.json** يقول لـ Vercel:
   - أي طلب يبدأ بـ `/api/` → روح للـ Express server
   - أي طلب ثاني → روح للـ `index.html` (SPA)

2. **api/index.ts** هو Express server يعالج:
   - `/api/trpc/*` → tRPC endpoints
   - `/api/oauth/*` → OAuth callbacks
   - `/manus-storage/*` → Storage proxy
   - أي طلب ثاني → يرجع `index.html` (SPA fallback)

---

## الخطوات الصحيحة للرفع

### 1. إعداد Git

```bash
git init
git add .
git commit -m "Vercel ready"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### 2. ربط بـ Vercel

اذهب إلى: https://vercel.com/new
- اختر GitHub
- اختر Repository
- اضغط **Import**

### 3. إضافة متغيرات البيئة (مهم جداً!)

**في Vercel Dashboard:**
1. اذهب إلى **Settings**
2. اختر **Environment Variables**
3. أضف كل متغير:

```
VITE_APP_ID = your_app_id
VITE_OAUTH_PORTAL_URL = https://oauth.manus.im
JWT_SECRET = your_secret_key
DATABASE_URL = mysql://user:password@host:3306/db
OAUTH_SERVER_URL = https://oauth.manus.im
OWNER_OPEN_ID = your_owner_id
BUILT_IN_FORGE_API_URL = https://api.manus.im
BUILT_IN_FORGE_API_KEY = your_api_key
NODE_ENV = production
```

**تنبيه:** لا تنسى الضغط على **Save** بعد كل متغير!

### 4. Redeploy

بعد إضافة المتغيرات:
1. اذهب إلى **Deployments**
2. اختر آخر deployment
3. اضغط **Redeploy**

---

## إذا لسه فيه 404؟

### الخطوة 1: تحقق من الملفات

تأكد من وجود:
- ✅ `vercel.json` في جذر المشروع
- ✅ `api/index.ts` موجود
- ✅ `dist/public/index.html` موجود

### الخطوة 2: شوف الـ Logs

في Vercel Dashboard:
1. اذهب إلى **Deployments**
2. اختر آخر deployment
3. اضغط على **Logs** وشوف الأخطاء

### الخطوة 3: Clean Build

1. اذهب إلى **Settings**
2. اختر **Git**
3. اضغط على **Disconnect**
4. ارجع وربط الـ Repository مرة ثانية

---

## الملفات المهمة

| الملف | الوصف |
|------|-------|
| `vercel.json` | إعدادات Vercel (Routing) |
| `api/index.ts` | Express server (Vercel Function) |
| `dist/public/` | الملفات الثابتة (React build) |
| `package.json` | Dependencies |

---

## كيفية عمل الرفع

### Build Phase
```
1. pnpm install
2. pnpm run build
   ↓
   Vite builds React → dist/public/
   ↓
   Static files ready
```

### Runtime Phase
```
Request comes in
    ↓
Is it /api/* ?
    ├─ YES → api/index.ts (Express)
    │        ├─ /api/trpc/* → tRPC handler
    │        ├─ /api/oauth/* → OAuth handler
    │        └─ /manus-storage/* → Storage proxy
    │
    └─ NO → Serve from dist/public/
             ├─ File found? → Serve it
             └─ File NOT found? → Serve index.html (SPA)
```

---

## أخطاء شائعة وحلولها

### ❌ Build Error: "Cannot find module"

**الحل:**
```bash
pnpm install
pnpm run build
```

### ❌ 500 Error: "Database connection failed"

**الحل:**
- تحقق من `DATABASE_URL` في Vercel
- تأكد من أن قاعدة البيانات متاحة
- تأكد من أن Vercel IP مسموح بالوصول

### ❌ 401 Error: "Unauthorized"

**الحل:**
- تحقق من `JWT_SECRET`
- تحقق من `VITE_APP_ID`
- تحقق من `OAUTH_SERVER_URL`

### ❌ CORS Error

**الحل:**
- تأكد من أن الـ Frontend والـ Backend على نفس الـ Domain
- تحقق من إعدادات CORS في Express

---

## متغيرات البيئة المطلوبة

| المتغير | الوصف | مثال |
|---------|-------|------|
| `VITE_APP_ID` | معرف التطبيق من Manus | `abc123` |
| `JWT_SECRET` | سر التوقيع | `your_secret_key` |
| `DATABASE_URL` | رابط قاعدة البيانات | `mysql://user:pass@host/db` |
| `OAUTH_SERVER_URL` | رابط OAuth | `https://oauth.manus.im` |
| `OWNER_OPEN_ID` | معرف المالك | `owner_id_123` |
| `BUILT_IN_FORGE_API_URL` | رابط Forge API | `https://api.manus.im` |
| `BUILT_IN_FORGE_API_KEY` | مفتاح Forge API | `api_key_123` |
| `VITE_OAUTH_PORTAL_URL` | رابط بوابة OAuth | `https://oauth.manus.im` |
| `NODE_ENV` | بيئة التشغيل | `production` |

---

## اختبار محلي

قبل الرفع على Vercel، جرب محلياً:

```bash
# بناء المشروع
pnpm run build

# تشغيل البناء محلياً
NODE_ENV=production node dist/index.js
```

ثم افتح: http://localhost:3000

---

## الدعم

- [Vercel Docs](https://vercel.com/docs)
- [Express Docs](https://expressjs.com/)
- [Manus Docs](https://docs.manus.im)

---

**آخر تحديث:** 24 يونيو 2026
